# image-compare

**Online demo: https://codesteppe.github.io/image-compare/**
